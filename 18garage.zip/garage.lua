function map()
	txd = engineLoadTXD ( "1.txd" )
		engineImportTXD ( txd, 2157 )
	col = engineLoadCOL ( "1.col" )
	dff = engineLoadDFF ( "1.dff", 0 )
	engineReplaceCOL ( col, 2157 )
	engineReplaceModel ( dff, 2157 )
	engineSetModelLODDistance(2157, 2000)

end

setTimer ( map, 1000, 1)
addCommandHandler("reloadmap",map)

addEventHandler("onClientResourceStop", getResourceRootElement(getThisResource()),
	function()
		engineRestoreCOL(2157)
		engineRestoreModel(2157)
		destroyElement(dff)
		destroyElement(col)
		destroyElement(txd)
	end
)