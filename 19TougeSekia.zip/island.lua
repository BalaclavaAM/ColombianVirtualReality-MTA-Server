function map()
	txd = engineLoadTXD ( "island.txd" )
		engineImportTXD ( txd, 1920 )
	col = engineLoadCOL ( "island.col" )
	dff = engineLoadDFF ( "island.dff", 0 )
	engineReplaceCOL ( col, 1920 )
	engineReplaceModel ( dff, 1920 )
	engineSetModelLODDistance(1920, 2000)

end

setTimer ( map, 1000, 1)
addCommandHandler("reloadmap",map)

addEventHandler("onClientResourceStop", getResourceRootElement(getThisResource()),
	function()
		engineRestoreCOL(1920)
		engineRestoreModel(1920)
		destroyElement(dff)
		destroyElement(col)
		destroyElement(txd)
	end
)