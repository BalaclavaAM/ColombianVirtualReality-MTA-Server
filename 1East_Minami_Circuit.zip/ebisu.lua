function ebisu()
	txd = engineLoadTXD ( "1.txd" )
		engineImportTXD ( txd, 2283 )
	col = engineLoadCOL ( "1.col" )
	dff = engineLoadDFF ( "1.dff", 0 )
	engineReplaceCOL ( col, 2283 )
	engineReplaceModel ( dff, 2283 )
	engineSetModelLODDistance(2283, 2000)
end

function chat()
		outputChatBox('Ebisu', player, 0, 255, 0)
		outputChatBox('Models By JC NEGRO .', player, 0, 255, 0)
		outputChatBox('Aportado por [ToR]MaCrO', player, 0, 255, 0)
		outputChatBox('Conversion a MTA por [GT]Scarface & [GT]zorrigas.', player, 0, 255, 0)
		outputChatBox('www.gtagamingchile.com.', player, 0, 255, 0)
end

setTimer ( ebisu, 1000, 1)
addCommandHandler("ebisu",ebisu)
addCommandHandler("ebisus",ebisu)
addCommandHandler("mapas",ebisu)
addCommandHandler("ebisu",chat)

addEventHandler("onClientResourceStop", getResourceRootElement(getThisResource()),
	function()
		engineRestoreCOL(2283)
		engineRestoreModel(2283)
		destroyElement(dff)
		destroyElement(col)
		destroyElement(txd)
	end
)