 addEventHandler ( "onResourceStart", getResourceRootElement(getThisResource()),
     function()
--Ebisu

createObject ( 2283, -820.107421875, 512.89978027344, 21.44261932373, 0, 0, 22.4990234375 )
createObject ( 1238, -823.825421875, 524.15778027344, 16.12261932373 )
createObject ( 1238, -829.204421875, 536.33978027344, 15.98161932373 )

     end
)
