function map()
	txd = engineLoadTXD ( "nikkocircuit.txd" )
		engineImportTXD ( txd, 2278 )
	col = engineLoadCOL ( "nikkocircuit.col" )
	dff = engineLoadDFF ( "nikkocircuit.dff", 0 )
	engineReplaceCOL ( col, 2278 )
	engineReplaceModel ( dff, 2278 )
	engineSetModelLODDistance(2278, 2000)

end

setTimer ( map, 1000, 1)
addCommandHandler("reloadmap",map)

addEventHandler("onClientResourceStop", getResourceRootElement(getThisResource()),
	function()
		engineRestoreCOL(2278)
		engineRestoreModel(2278)
		destroyElement(dff)
		destroyElement(col)
		destroyElement(txd)
	end
)