addEventHandler ("onClientResourceStart", getResourceRootElement(getThisResource()),
	function()
		col = engineLoadCOL ("COL/akina1.col")
		col1 = engineLoadCOL ("COL/akina2.col")
		col2 = engineLoadCOL ("COL/akina3.col")
		col3 = engineLoadCOL ("COL/akina4.col")
		col4 = engineLoadCOL ("COL/akina5.col")
		engineReplaceCOL (col, 2617)
		engineReplaceCOL (col1, 2572)
		engineReplaceCOL (col2, 2571)
		engineReplaceCOL (col3, 2357)
		engineReplaceCOL (col4, 2290)

		txd = engineLoadTXD ("TXD/akina.txd")
		engineImportTXD (txd, 2617)
		engineImportTXD (txd, 2572)
		engineImportTXD (txd, 2571)
		engineImportTXD (txd, 2357)
		engineImportTXD (txd, 2290)

		dff = engineLoadDFF ("DFF/akina1.dff", 0)
		dff1 = engineLoadDFF ("DFF/akina2.dff", 0)
		dff2 = engineLoadDFF ("DFF/akina3.dff", 0)
		dff3 = engineLoadDFF ("DFF/akina4.dff", 0)
		dff4 = engineLoadDFF ("DFF/akina5.dff", 0)

		engineReplaceModel (dff, 2617)
		engineReplaceModel (dff1, 2572)
		engineReplaceModel (dff2, 2571)
		engineReplaceModel (dff3, 2357)
		engineReplaceModel (dff4, 2290)

		engineSetModelLODDistance(2617, 300)
		engineSetModelLODDistance(2572, 300)
		engineSetModelLODDistance(2571, 300)
		engineSetModelLODDistance(2357, 300)
		engineSetModelLODDistance(2290, 300)
	end
);

addEventHandler("onClientResourceStop", getResourceRootElement(getThisResource()),
	function()
		engineRestoreCOL(2617)
		engineRestoreCOL(2572)
		engineRestoreCOL(2571)
		engineRestoreCOL(2357)
		engineRestoreCOL(2290)

		engineRestoreModel(2617)
		engineRestoreModel(2572)
		engineRestoreModel(2571)
		engineRestoreModel(2357)
		engineRestoreModel(2290)

		destroyElement(dff)
		destroyElement(dff1)
		destroyElement(dff2)
		destroyElement(dff3)
		destroyElement(dff4)

		destroyElement(col)
		destroyElement(col1)
		destroyElement(col2)
		destroyElement(col3)
		destroyElement(col4)

		destroyElement(txd)
	end
);