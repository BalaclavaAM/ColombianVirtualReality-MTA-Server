﻿local positions =
    {
        {-2930.5, 475.60546875, 4.9065704345703},
        {-2930.5, 475.60546875, 4.9065704345703},
        {-2930.5, 475.60546875, 4.9065704345703},
    }

function TP(thePlayer, command)
	nonTPvehicles = {[425]=true, [520]=true, [476]=true, [447]=true, [464]=true, [432]=true}
    local calc = math.random (#positions)
	local vehicle = getPedOccupiedVehicle(thePlayer)
		if vehicle then
			local vehModel = getElementModel(vehicle)
			if (getPedOccupiedVehicleSeat(thePlayer) ~= 0) then return end
			if (nonTPvehicles[vehModel]) then outputChatBox("You cannot use /akina while in this specific vehicle!", thePlayer) return end
			setElementPosition(vehicle, unpack (positions [calc]))
		else
			setElementPosition(thePlayer, unpack (positions [calc]))
		end
end
addCommandHandler ("akina", TP)