local isSpeaker = false

function print(player, message, r, g, b)
    outputChatBox(message, player, r, g, b)
end

speakerBox = {}
function manageSpeaker(thePlayer)
	if (isElement(speakerBox[thePlayer])) then
		isSpeaker = true
	end
		triggerClientEvent(thePlayer, "onPlayerViewSpeakerManagement", thePlayer, isSpeaker)
end

addCommandHandler("sound",manageSpeaker)
addCommandHandler("music",manageSpeaker)
addCommandHandler("bafle",manageSpeaker)

addEvent("onPlayerPlaceSpeakerBox", true)
addEventHandler("onPlayerPlaceSpeakerBox", root,
    function(url, isCar)
        if (url) then
            if string.len(url) < 150 then
                if (isElement(speakerBox[source])) then
                    local x, y, z = getElementPosition(speakerBox[source])
                    print(source,"Destroyed old speaker located at: " .. math.floor(x) .. ", " .. math.floor(y) .. ", " .. math.floor(z),255,0,0)
                    destroyElement(speakerBox[source])
                    removeEventHandler("onPlayerQuit", source, destroySpeakersOnPlayerQuit)
                end
                local x, y, z = getElementPosition(source)
                local rx, ry, rz = getElementRotation(source)
                speakerBox[source] = createObject(2229, x - 0.5, y + 0.5, z - 1, 0, 0, rx)
                setElementCollisionsEnabled(speakerBox[source], false)
                setElementInterior(speakerBox[source], getElementInterior(source))
                setElementDimension(speakerBox[source], getElementDimension(source))
                print(source,"Speaker box placed at " .. math.floor(x) .. ", " .. math.floor(y) .. ", " .. math.floor(z),0,255,0)
                addEventHandler("onPlayerQuit", source, destroySpeakersOnPlayerQuit)
                triggerClientEvent(root, "onPlayerStartSpeakerBoxSound", root, source, url, isCar)
                if (isCar) then
                    local car = getPedOccupiedVehicle(source)
                    attachElements(speakerBox[source], car, -0.7, -1.5, -0.5, 0, 90, 0)
                end
            end
        end
    end
)

addEvent("onPlayerDestroySpeakerBox", true)
addEventHandler("onPlayerDestroySpeakerBox",root,
    function()
        if (isElement(speakerBox[source])) then
            destroyElement(speakerBox[source])
            triggerClientEvent(root, "onPlayerDestroySpeakerBox", root, source)
            removeEventHandler("onPlayerQuit", source, destroySpeakersOnPlayerQuit)
            print(source, "Speaker box has been removed.", 255, 0, 0)
        else
            print(source, "You don't have a speaker box.", 255, 255, 0)
        end
    end
)

addEvent("onPlayerChangeSpeakerBoxVolume", true)
addEventHandler("onPlayerChangeSpeakerBoxVolume", root,
    function(to)
        triggerClientEvent(root, "onPlayerChangeSpeakerBoxVolumeC", root, source, to)
    end
)

function destroySpeakersOnPlayerQuit()
    if (isElement(speakerBox[source])) then
        destroyElement(speakerBox[source])
        triggerClientEvent(root, "onPlayerDestroySpeakerBox", root, source)
    end
end