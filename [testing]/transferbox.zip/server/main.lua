addEventHandler("onResourceStart", resourceRoot, function()
    setTransferBoxVisible(false)
end)