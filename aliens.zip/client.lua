﻿txd = engineLoadTXD("a/259.txd", 259 )
engineImportTXD(txd, 259)
dff = engineLoadDFF("a/259.dff", 259 )
engineReplaceModel(dff, 259)
txd = engineLoadTXD("a/258.txd", 258 )
engineImportTXD(txd, 258)
dff = engineLoadDFF("a/258.dff", 258 )
engineReplaceModel(dff, 258) 
txd = engineLoadTXD("a/447.txd")
engineImportTXD(txd, 447)
dff = engineLoadDFF("a/447.dff", 447)
engineReplaceModel(dff, 447)


addEvent ( "aliensound", true )
addEventHandler ( "aliensound", root,
    function ( )
		local aliensound3d = playSound("a/ufo.mp3") 
    end
)
addEvent ( "callSetPedControlState", true )
addEventHandler("callSetPedControlState", root,
function (thePed, control, bol)
    setPedControlState( thePed, control, bol )
end)