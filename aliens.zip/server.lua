﻿--[[ Aliens script by manawydan.
thank you slothman for resource slothbot 
thank you solidsnake for resource extrahealth
thank you Anderl & DNL291 for help
you can modify it
This script is just a prototype. thanks for download ]]--

createTeam ( "?", 0, 0, 225 )
local team = getTeamFromName ( "?" )
setTeamFriendlyFire(team,false) 
local coords = {
	{231.9, 1874.91, 17.64},
	{250.86, 1875.48, 20.64},
	{175.27, 1882.66, 20.87},
	{141.76, 1889.13, 18.29},
	{149.77, 1876.02, 17.93},
	{152.42, 1867.58, 17.83},
	{170.16, 1871.68, 20.77},
	{210.48, 1871.82, 17.64},
	{226.32, 1891.71, 17.64},
	{218.94, 1868.68, 13.14},
	{242.88, 1871.97, 11.45},
	{246.9, 1849.47, 8.77},
	{249.09, 1825.7, 7.55},
	{274.37, 1869.47, 8.76},
	{268.73, 1816.19, 4.7},
	{219.95, 1823.5, 7.55},
	{266.28, 1815.49, 4.7}
	
}

function alienBymanawydan (thePlayer)
local accName = getAccountName ( getPlayerAccount ( thePlayer ) ) 
     if isObjectInACLGroup ("user."..accName, aclGetGroup ( "Admin" ) ) then 
local ufo1 = createObject ( 1381, 314.22, 1866.52, 88.97, 0, 0, 0 )
moveObject ( ufo1, 300000, 179.87, 1995.21, 41.53 )
--setWeather ( 9 )
setTime ( 23, 59 )
local slothBot = exports [ "slothBot" ]:spawnBot ( 268.65, 1883.84, -30.09, 90,  math.random ( 300, 303 ), 0, 0, team, 38,         "guarding", true )
--local myBlip = createBlip ( 389.65396118164, 2516.5590820313, 17.0, 23 )
--attachElements ( myBlip, slothBot, 0, 0, 1 )
      --exports.extrahealth:setElementExtraHealth ( slothbot, 8000 )
	  exports.extra_health:setElementExtraHealth ( slothbot, 150 )
      setElementModel ( slothBot, 259 )
	  for k,v in ipairs(coords) do 
		local alien =  exports [ "slothBot" ]:spawnBot ( v[1], v[2], v[3], 90,  math.random ( 300, 303 ), 0, 0, team, 31,         "waiting", true )
		setElementModel(alien,258)
		exports.extra_health:setElementExtraHealth ( alien, 80 )
	  end
triggerClientEvent ( "aliensound", root )   
AlienPilot1 = exports [ "slothBot" ]:spawnBot ( 179.87, 1995.21, 41.53, 90,  math.random ( 300, 303 ), 0, 0, team, 31,         "guarding", true )
setElementModel ( AlienPilot1, 258 ) 
UfoPilot = createVehicle(447, 224.55, 1883.71, 17.64)
warpPedIntoVehicle ( AlienPilot1, UfoPilot )
triggerClientEvent ( "callSetPedControlState", root, AlienPilot1, "accelerate", true)
local time1 = setTimer(
      function()
      triggerClientEvent ( "callSetPedControlState", root, AlienPilot1, "vehicle_right", true)
      end, 5000, 1)
      setElementAlpha(slothBot , 70)

end
end
addCommandHandler("aliens", alienBymanawydan)
      
local alienSkins = {[258]=true,[259]=true}

addEvent("onBotWasted", true)
addEventHandler("onBotWasted", root, function( killer )
    if alienSkins[getElementModel( source)] then
    givePlayerMoney(killer,math.random(10000,20000))
    end
end)


function UfoDestroyer()
if (source == UfoPilot) then
local jogador = getRandomPlayer ( )
	givePlayerMoney(jogador, 20000)
	outputChatBox ("#2C04CENave madre destruida!", getRootElement(), 255, 255, 255, true )
	destroyElement(UfoPilot)
	destroyElement(AlienPilot1)
end
end
addEventHandler("onVehicleExplode", getRootElement(), UfoDestroyer)