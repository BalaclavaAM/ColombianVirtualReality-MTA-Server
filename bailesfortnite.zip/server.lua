﻿ 
function setPedFortniteAnimation (ped,animation,tiempo,repetir,mover,interrumpible)
if (type(animation) ~= "string" or type(tiempo) ~= "number" or type(repetir) ~= "boolean" or type(mover) ~= "boolean" or type(interrumpible) ~= "boolean") then return false end
if isElement(ped) then
if animation == "baile 1" or animation == "baile 2" or animation == "baile 3" or animation == "baile 4" or animation == "baile 5" or animation == "baile 6" or animation == "baile 7" or animation == "baile 8" or animation == "baile 9" or animation == "baile 10" or animation == "baile 11" or animation == "baile 12" or animation == "baile 13" then
for i = 1,3 do
triggerClientEvent ( root, "setPedFortniteAnimation", root, ped,animation,tiempo,repetir,mover,interrumpible )
if tiempo > 1 then
setTimer(setPedAnimation,tiempo,1,ped,false)
setTimer(setPedAnimation,tiempo+100,1,ped,false)
end
end
end
end
 
end
--[[
EJEMPLO/EXAMPLE
CUANDO CAMBIA EL NICK
WHEN NICK IS CHANGED

function wasNickChangedByUser(oldNick, newNick, changedByUser)
setPedFortniteAnimation(source,"baile 8",7000,true,false,false,false)
end
addEventHandler("onPlayerChangeNick", getRootElement(), wasNickChangedByUser) -- add an event handler




--]]


function getElementSpeed(theElement, unit)
    -- Check arguments for errors
    assert(isElement(theElement), "Bad argument 1 @ getElementSpeed (element expected, got " .. type(theElement) .. ")")
    local elementType = getElementType(theElement)
    assert(elementType == "player" or elementType == "ped" or elementType == "object" or elementType == "vehicle" or elementType == "projectile", "Invalid element type @ getElementSpeed (player/ped/object/vehicle/projectile expected, got " .. elementType .. ")")
    assert((unit == nil or type(unit) == "string" or type(unit) == "number") and (unit == nil or (tonumber(unit) and (tonumber(unit) == 0 or tonumber(unit) == 1 or tonumber(unit) == 2)) or unit == "m/s" or unit == "km/h" or unit == "mph"), "Bad argument 2 @ getElementSpeed (invalid speed unit)")
    -- Default to m/s if no unit specified and 'ignore' argument type if the string contains a number
    unit = unit == nil and 0 or ((not tonumber(unit)) and unit or tonumber(unit))
    -- Setup our multiplier to convert the velocity to the specified unit
    local mult = (unit == 0 or unit == "m/s") and 50 or ((unit == 1 or unit == "km/h") and 180 or 111.84681456)
    -- Return the speed by calculating the length of the velocity vector, after converting the velocity to the specified unit
    return (Vector3(getElementVelocity(theElement)) * mult).length
end


function Baile1 (thePlayer)
if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 1",7000,true,false,false,false)
end
addCommandHandler("baile1",Baile1)

function Baile2 (thePlayer)
if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 2",7000,true,false,false,false)
end
addCommandHandler("baile2",Baile2)

function Baile3 (thePlayer)
if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 3",7000,true,false,false,false)
end
addCommandHandler("baile3",Baile3)

function Baile4 (thePlayer)
if getElementSpeed(thePlayer)>0 then return end
if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 4",7000,true,false,false,false)
end
addCommandHandler("baile4",Baile4)

function Baile5 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 5",7000,true,false,false,false)
end
addCommandHandler("baile5",Baile5)

function Baile6 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 6",7000,true,false,false,false)
end
addCommandHandler("baile6",Baile6)

function Baile7 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 7",7000,true,false,false,false)
end
addCommandHandler("baile7",Baile7)

function Baile8 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 8",7000,true,false,false,false)
end
addCommandHandler("baile8",Baile8)

function Baile9 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 9",7000,true,false,false,false)
end
addCommandHandler("baile9",Baile9)

function Baile10 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 10",7000,true,false,false,false)
end
addCommandHandler("baile10",Baile10)

function Baile11 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 11",7000,true,false,false,false)
end
addCommandHandler("baile11",Baile11)

function Baile12 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 12",7000,true,false,false,false)
end
addCommandHandler("baile12",Baile12)

function Baile13 (thePlayer)
    if getElementSpeed(thePlayer)>0 then return end
setPedFortniteAnimation(thePlayer,"baile 13",7000,true,false,false,false)
end
addCommandHandler("baile13",Baile13)