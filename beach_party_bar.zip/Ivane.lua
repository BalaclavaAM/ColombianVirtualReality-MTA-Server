-- DDC OMG generated script, PLACE IT SERVER-SIDE

function omg_md93()
  md93 = createObject(5837, 507, -1877.3, 3.9, 0, 0, 270)
  omgMovemd93(1)
end

function omgMovemd93(point)
  if point == 1 then
    moveObject(md93, 5837, 507, -1877.3, 47.2)
    setTimer(omgMovemd93, 11000, 1, 2)
  elseif point == 2 then
    moveObject(md93, 5837, 507, -1877.3, 3.9)
    setTimer(omgMovemd93, 11000, 1, 1)
  end
end

addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), omg_md93)