Blackjack v.1.03

Install:
upload to your resource folder within the mta-server

Useage:
type "startBJ" in the Chat (without ""), Play the game ;)

Help on Black Jack:
Your Goal, get more Point than the Bank but dont get over 21 Points

Card Values

Numbers 2-10 count the value they display
Pictures (Kings, etc) are counting 10 Point
The Ace counts 1 or 11 Point depending on the situation.

21 Points with two cards for example Ace + 10 is called a Black Jack and is a instand win for the Bank and the Player.

Buttons:

Hit: Dealer Gives you one card
Double: Can be used when you have two cards, doubles your bet and you get one more card.
Stand: Your satisfied with your cards,
Surrender: Surrender your Hand you gain 50% (default) of your bet.