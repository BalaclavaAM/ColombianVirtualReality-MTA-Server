function hood(player)


	local newcar = getPedOccupiedVehicle (player)
	openratio = getVehicleDoorOpenRatio( newcar,0)
	if not newcar then
		triggerClientEvent(player,"doOutput",player,0,255,0,"Get inside vehicle to use this command")
	end

	if openratio < 1 then	
		state =  setVehicleDoorOpenRatio ( newcar,0,1,1000)
			triggerClientEvent(player,"doOutput",player,0,255,0,"Vehicle's hood is now open")
	else
		state =  setVehicleDoorOpenRatio ( newcar,0,0,1000)
			triggerClientEvent(player,"doOutput",player,0,255,0,"Vehicle's hood is now closed")
	end
end
addCommandHandler("hood",hood)

function trunk(player)
local newcar = getPedOccupiedVehicle (player)
openratio = getVehicleDoorOpenRatio( newcar,1)
 if not newcar then
					triggerClientEvent(player,"doOutput",player,0,255,0,"Get inside vehicle to use this command")
end
 if openratio < 1 then
	state =  setVehicleDoorOpenRatio ( newcar,1,1,1000)
			triggerClientEvent(player,"doOutput",player,0,255,0,"Vehicle's trunk is now open")
else
	state =  setVehicleDoorOpenRatio ( newcar,1,0,1000)
			triggerClientEvent(player,"doOutput",player,0,255,0,"Vehicle's trunk is now closed")
end
end
addCommandHandler("trunk",trunk)

function door(player,command,door)
local newcar = getPedOccupiedVehicle (player)
door = tonumber(door)
openratio = getVehicleDoorOpenRatio( newcar,door)
if not door then
	outputChatBox("Syntax: /door number",player,255,255,255)
	outputChatBox("0 (hood), 1 (trunk), 2 (front left), 3 (front right), 4 (rear left), 5 (rear right)",player,255,255,255)
end

 if not newcar then
		triggerClientEvent(player,"doOutput",player,0,255,0,"Get inside vehicle to use this command")
end
 if openratio < 1 then
	state =  setVehicleDoorOpenRatio (newcar,door,1,1000)

			triggerClientEvent(player,"doOutput",player,0,255,0,"Vehicle's door is now open")
else
	state =  setVehicleDoorOpenRatio ( newcar,door,0,1000)

	triggerClientEvent(player,"doOutput",player,0,255,0,"Vehicle's door is now closed")
end
end
addCommandHandler("door",door)