function replaceModel()
  txd = engineLoadTXD("em.txd", 1898 )
  engineImportTXD(txd, 1898)
  dff = engineLoadDFF("em.dff", 1898 )
  engineReplaceModel(dff, 1898)
  col= engineLoadCOL ( "em.col" )
  engineReplaceCOL ( col, 1898 )
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)