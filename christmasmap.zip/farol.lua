﻿txd = engineLoadTXD ( "vgnlpost.txd" )
engineImportTXD ( txd, 3472 )
engineSetModelLODDistance(3472,7910, 9000090000900009000090000900009000090000)