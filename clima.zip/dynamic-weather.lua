function dynamicweather()
  local variable = math.random(0,18)
    if variable == 8 then
    variable = 18
  end
  setWeatherBlended ( variable )
  setTimer( dynamicweather, math.random( 180000, 720000 ), 1 )
end

setTimer( dynamicweather, 3000, 1 )