addCommandHandler ( "versions", 
  function ( player ) 
    outputChatBox ( "#FCE059Pothole Dynamic Weather #FFFFFFV3.1.5 #A85AFF[15-June-2010]", player, 255, 255, 255, true ) 
  end 
)