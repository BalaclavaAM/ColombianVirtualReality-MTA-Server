--[[
original script by Justus (GA_Justus)
--]]

function saveClothes()
	local account = getPlayerAccount(source)
	if ( not isGuestAccount(account) ) and ( getElementModel(source) == 0 ) then
		local texture = {}
		local model = {}
		for i=0, 17, 1 do
			local clothesTexture, clothesModel = getPedClothes(source, i)
			if ( clothesTexture ~= false ) then
				table.insert(texture, clothesTexture)
				table.insert(model, clothesModel)
			else
				table.insert(texture, " ")
				table.insert(model, " ")
			end	
		end
		local allTextures = table.concat(texture, ",")
		local allModels = table.concat(model, ",")
		outputDebugString("Clothessaver: Saved clothes")
		setAccountData(account, "Clothessaver:Texture", allTextures)
		setAccountData(account, "Clothessaver:Model", allModels)
		texture = {}
		model = {}
	end
end
addEventHandler("onPlayerQuit", getRootElement(), saveClothes)

function setClothes()
	local account = getPlayerAccount(source)
	if ( not isGuestAccount(account) and getElementModel(source) == 0 ) then
		local textureString = getAccountData(account, "Clothessaver:Texture")
		local modelString = getAccountData(account, "Clothessaver:Model")
		local textures = split(textureString, 44)
		local models = split(modelString, 44)
		setElementModel(source,0)
		for i=0, 17, 1 do
			if ( textures[i+1] ~= " " ) then
				addPedClothes(source, textures[i+1], models[i+1], i)
			end
		end
		--outputChatBox("Clothes were added by clothessaver", source, 0, 255, 0)
		textures = {}
		models = {}
	end
end
addEventHandler("onPlayerLogin", getRootElement(), setClothes)

function loadClothes(player)
	local account = getPlayerAccount(player)
	if ( not isGuestAccount(account) ) then
		local textureString = getAccountData(account, "Clothessaver:Texture")
		local modelString = getAccountData(account, "Clothessaver:Model")
		local textures = split(textureString, 44)
		local models = split(modelString, 44)
		setElementModel(player,0)
		for i=0, 17, 1 do
			if ( textures[i+1] ~= " " ) then
				addPedClothes(player, textures[i+1], models[i+1], i)
			end
		end
		outputChatBox("Clothes were added by clothessaver", player, 0, 255, 0)
		textures = {}
		models = {}
	else
		outputChatBox("Please login!", player, 255, 0, 0)
	end
end
addCommandHandler("loadClothes", loadClothes)

function saveClothes(player)
	local account = getPlayerAccount(player)
	if ( not isGuestAccount(account) ) then
		if ( getElementModel(player) == 0 ) then
			local texture = {}
			local model = {}
			for i=0, 17, 1 do
				local clothesTexture, clothesModel = getPedClothes(player, i)
				if ( clothesTexture ~= false ) then
					table.insert(texture, clothesTexture)
					table.insert(model, clothesModel)
				else
					table.insert(texture, " ")
					table.insert(model, " ")
				end
			end
			local allTextures = table.concat(texture, ",")
			local allModels = table.concat(model, ",")
			outputDebugString("Clothessaver: Saved clothes")
			setAccountData(account, "Clothessaver:Texture", allTextures)
			setAccountData(account, "Clothessaver:Model", allModels)
			texture = {}
			model = {}
		else
			outputChatBox("Your skin must be skin 0 (CJ Skin)", player, 255, 0, 0)
		end
	else
		outputChatBox("Please login!", player, 255, 0, 0)
	end
end
addCommandHandler("saveClothes", saveClothes)