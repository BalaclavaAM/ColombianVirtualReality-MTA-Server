﻿x,y,z,fwp,bl = false,false,false,false,false
function mf(p)
    if not isElement(fwp) and x then destroyElement(bl) fwp,x,y,z,bl = false,false,false,false,false end
     if not x then
        x,y,z = getElementPosition(p)
        fwp = p
        outputChatBox("Player #ffffff"..getPlayerName(p).."#00ff00, launch command for  #cc4444foreworks#00ff00 successfully!",root,0,255,0,true)
        outputChatBox("Confirm that you want to is shoot? Repeat command /fireworks for yes confirm!",p,0,255,0)
        bl = createBlip(x,y,z,19)
     elseif fwp == p then
        triggerClientEvent("makeFireworks", root, p,x,y,z)
        outputChatBox(getPlayerName(p).."#00ff00 fireworks shoot!",root,255,255,255,true)
        setTimer(destroyElement,10000,1,bl)
        bl,fwp,x,y,z = false,false,false,false,false
     end
end
addCommandHandler("fireworks", mf)