****************************
*Created by MazzMan
****************************

You can change the Sounds by just replacing the old sounds with the new sounds. You have to keep the names!!!



Credits: MazzMan

Have fun :D