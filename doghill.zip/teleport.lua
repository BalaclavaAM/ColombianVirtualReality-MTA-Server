function dog (playerSource)
	local vehicle = getPedOccupiedVehicle(playerSource)
	   if vehicle then
	setElementPosition (vehicle, -160.48, 2919.25, 61)
	   else
	setElementPosition (playerSource, -160.48, 2919.25, 61)
	end
end
addCommandHandler ( "dog", dog )