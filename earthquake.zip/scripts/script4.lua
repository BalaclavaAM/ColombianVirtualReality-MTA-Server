--=========================================================================--
--       _________   ___________   _       ______  __    ___________       --
--      / ____/   | / ___/_  __/  | |     / / __ \/ /   / ____/ ___/       --
--     / /_  / /| | \__ \ / /     | | /| / / / / / /   / /_   \__ \        --
--    / __/ / ___ |___/ // /      | |/ |/ / /_/ / /___/ __/  ___/ /        --
--   /_/   /_/  |_/____//_/       |__/|__/\____/_____/_/    /____/         --
--=========================================================================--


--Include resoures download please
--DON'T EDIT/COPY/SEND/SELL PLEASE  (but commands and text yes)
--onResourceStart 
--04
--Client

function gravstop ()
setGravity ( tonumber(0.004) )
end
addEvent ( "gravstopp", true)
addEventHandler ( "gravstopp", getRootElement(), gravstop )

function gravstopr ()
setGravity ( tonumber(-0.005) )
end
addEvent ( "gravstoppe", true)
addEventHandler ( "gravstoppe", getRootElement(), gravstopr )

function gravstoprr ()
setGravity ( tonumber(0.409) )
end
addEvent ( "grae", true)
addEventHandler ( "grae", getRootElement(), gravstoprr )

--===--
--FAST WOLFS ® All rights reserved, © Erik Ivan Aranda.
--Facebook: https://www.facebook.com/fastwolfs.fw/?fref=ts
--Page Official: http://fast-wolfs.xyz
--===--