function Window ( )

        if ( guiGetVisible ( myWindow ) == true ) then   
        
                guiSetVisible ( myWindow, false )

                showCursor ( false )
        else      
                guiSetVisible ( myWindow, true )

                showCursor ( true )
        end
end


myWindow = guiCreateWindow ( 0.16, 0.0, .7, .7, "�������� JDMlegends", true )


local tabPanel = guiCreateTabPanel ( 0, 0.1, 1, 1, true, myWindow )
local Teleports = guiCreateTab( "Teleport Drift Track", tabPanel )




--GUI Buttons
LSAirport = guiCreateButton( 0.03, 0.01, 0.18, 0.12, "Touge Akina UP", true, Teleports )
guiSetFont ( LSAirport, "default-bold-small" )

LVAirport = guiCreateButton( 0.03, 0.13, 0.18, 0.12, "Touge Akina Down", true, Teleports )
guiSetFont ( LVAirport, "default-bold-small" )

AbandedAirstrip = guiCreateButton( 0.03, 0.25, 0.18, 0.12, "Touge Bihoku", true, Teleports )
guiSetFont ( AbandedAirstrip, "default-bold-small" )

SFAirport = guiCreateButton( 0.03, 0.37, 0.18, 0.12, "Drift Stage", true, Teleports )
guiSetFont ( SFAirport, "default-bold-small" )

MountChiliad = guiCreateButton( 0.03, 0.49, 0.18, 0.12, "East Minami Circuit", true, Teleports )
guiSetFont ( MountChiliad, "default-bold-small" )

WangCars = guiCreateButton( 0.03, 0.61, 0.18, 0.12, "Meihancircuit", true, Teleports )
guiSetFont ( WangCars, "default-bold-small" )

Ottos = guiCreateButton( 0.4, 0.01, 0.18, 0.12, "Drift Track", true, Teleports )
guiSetFont ( Ottos, "default-bold-small" )

Area51 = guiCreateButton( 0.4, 0.13, 0.18, 0.12, "Touge Ebisu Soutch", true, Teleports )
guiSetFont ( Area51, "default-bold-small" )

BigEar = guiCreateButton( 0.4, 0.25, 0.18, 0.12, "Touge Ebisu West", true, Teleports )
guiSetFont ( BigEar, "default-bold-small" )

BlueBerry = guiCreateButton( 0.4, 0.37, 0.18, 0.12, "Touge Project Touge", true, Teleports )
guiSetFont ( BlueBerry, "default-bold-small" )

Heli = guiCreateButton( 0.4, 0.49, 0.18, 0.12, "Touge Nikko", true, Teleports )
guiSetFont ( Heli, "default-bold-small" )

Grove = guiCreateButton( 0.4, 0.61, 0.18, 0.12, "Nakayubi", true, Teleports )
guiSetFont ( Grove, "default-bold-small" )

Dam = guiCreateButton( 0.77, 0.01, 0.18, 0.12, "Touge Okaru", true, Teleports )
guiSetFont ( Dam, "default-bold-small" )

BackBeyond = guiCreateButton( 0.77, 0.13, 0.18, 0.12, "Touge Gokart", true, Teleports )
guiSetFont ( BackBeyond, "default-bold-small" )

Quarry = guiCreateButton( 0.77, 0.25, 0.18, 0.12, "Ultra Nitro Track", true, Teleports )
guiSetFont ( Quarry, "default-bold-small" )

Bayside = guiCreateButton( 0.77, 0.37, 0.18, 0.12, "Touge Sekia.", true, Teleports )
guiSetFont ( Bayside, "default-bold-small" )

Pecker = guiCreateButton( 0.77, 0.49, 0.18, 0.12, "Tsukuba", true, Teleports )
guiSetFont ( Pecker, "default-bold-small" )

Bridge = guiCreateButton( 0.77, 0.61, 0.18, 0.12, "Fantazy Hill", true, Teleports )
guiSetFont ( Bridge, "default-bold-small" )


Redring = guiCreateButton( 0.4, 0.78, 0.18, 0.063, "������� ������", true, Teleports )
guiSetFont ( Close, "default-bold-small" )
Garage = guiCreateButton( -0.08, 0.87, 1.1, 0.063, "Garage", true, Teleports )
guiSetFont ( Close, "default-bold-small" )
Close = guiCreateButton( -0.08, 0.94, 1.1, 0.063, "������� ��������'F2'", true, Teleports )
guiSetFont ( Close, "default-bold-small" )


bindKey ( "F4", "down", Window )


guiSetAlpha ( myWindow, 1 )
guiWindowSetSizable ( myWindow, false )

--Label Color
function changeLabelColor ( )

	guiLabelSetColor ( One, math.random(0, 255), math.random(0, 255), math.random(0, 255) )
end

setTimer ( changeLabelColor, 1000, 0 )


--Close
addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
           if (source == Close) then
           guiSetVisible( myWindow, false )
           showCursor( false )
                end  

           end
)


--Teleports
addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == MountChiliad) then
            local player = getLocalPlayer()
                    setElementPosition (player , -877.7409667969, 520.6766357422, 14.1091003418  )
            end
          end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == LSAirport) then
            local player = getLocalPlayer()
                        setElementPosition (player , -3289.7409667969, 890.6766357422, 322.1091003418  ) 
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == LVAirport) then
            local player = getLocalPlayer()
                  setElementPosition (player , -2926.9138183594, 487.1204833984, 5.2602405548  )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == AbandedAirstrip) then
            local player = getLocalPlayer()
                  setElementPosition (player , -3266.59480957031, -1067.1661152344, 13.2322671096  ) 
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == SFAirport) then
            local player = getLocalPlayer()
                  setElementPosition (player , -3112.1933, -868.0136820678711, 10.471401863098  ) 
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == WangCars) then
            local player = getLocalPlayer()
                  setElementPosition (player , -2844, 1483.881521875, 49.9797288131714  )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Ottos) then
            local player = getLocalPlayer()
                  setElementPosition (player , 1326.7004394531, -2840.574921875, 9.8597288131714  )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Area51) then
            local player = getLocalPlayer()
                  setElementPosition (player , -824.61033300781, 2192.1982431641, 123.08539108276  ) 
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == BigEar) then
            local player = getLocalPlayer()
                  setElementPosition (player , 174.56447021484, 3035.1215283203, 29.465629577637  )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == BlueBerry) then
            local player = getLocalPlayer()
                  setElementPosition (player , 2969.3661103248596, -1723.78341293335, 37.5212655067444  )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Heli) then
            local player = getLocalPlayer()
                  setElementPosition (player , -2246.39447021484, 2099.9415283203, 5.965629577637  )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Grove) then
            local player = getLocalPlayer()
                  setElementPosition (player , -311.3193359375, -3027.1716308594, 50.765625 )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Dam) then
            local player = getLocalPlayer()
                  setElementPosition (player , -4235.02734375, 633.9217529297, 620.654315948486 )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == BackBeyond) then
            local player = getLocalPlayer()
                  setElementPosition (player , 3409.93298339844, 1335.8010253906, 20.003288269043 )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Quarry) then
            local player = getLocalPlayer()
                  setElementPosition (player , -3449.7600, -1642.94840595703, 61.8789616699 )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Bayside) then
            local player = getLocalPlayer()
                  setElementPosition (player , 2082.322290625, -142.640660156, 28.9991247940063 )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Pecker) then
            local player = getLocalPlayer()
                  setElementPosition (player , 140.91618725586, 637.1567421875, 420.863159790039 )
            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Bridge) then
            local player = getLocalPlayer()
                  setElementPosition (player , 827.9711, -2061.2324, 13.86 )

            end
         end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Garage) then
            local player = getLocalPlayer()
                    setElementPosition (player , 2591.8709667969, -2347.7366357422, 13.652  )
            end
          end
)

addEventHandler ( "onClientGUIClick", getResourceRootElement(getThisResource()),
        function ( )
            if (source == Redring) then
            local player = getLocalPlayer()
                    setElementPosition (player , -566.404409667969, -649.5066357422, 326.252  )
            end
          end
)