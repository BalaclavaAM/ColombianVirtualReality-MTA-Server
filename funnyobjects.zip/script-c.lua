﻿-----------------------
----FunnyObjects
--- Script made by [SORC]Markeloff
--- 94.102.53.183:22004
--- Skype : markeloff.smith
-----------------------




addCommandHandler("fly",
	function ( cmd )
		if not isWorldSpecialPropertyEnabled( "aircars" ) then
			setWorldSpecialPropertyEnabled( "aircars", true )
		else
			setWorldSpecialPropertyEnabled( "aircars", false )
		end
	end
)

addCommandHandler("swim",
	function ( cmd )
		if not isWorldSpecialPropertyEnabled( "hovercars" ) then
			setWorldSpecialPropertyEnabled( "hovercars", true )
		else
			setWorldSpecialPropertyEnabled( "hovercars", false )
		end
	end
)