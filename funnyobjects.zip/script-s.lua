﻿-----------------------
----FunnyObjects
--- Script made by [SORC]Markeloff
--- 94.102.53.183:22004
--- Skype : markeloff.smith
-----------------------

function Pirate(player)
if isPedInVehicle (player) then 
local car = getPedOccupiedVehicle(player)
x,y,z = getElementPosition(player)
local pirate = createObject(8493, x, y, z+30)
attachElements(pirate, car,0,0,17)
addEventHandler ( "onVehicleExplode", root, Exploded )
addEventHandler ( "onPlayerQuit", root, Exploded )
end
end
addCommandHandler("pirate", Pirate)


function cow(player)
if isPedInVehicle (player) then 
local car = getPedOccupiedVehicle(player)
x,y,z = getElementPosition(player)
local cow = createObject(11470, x, y, z+10)
attachElements(cow, car)
addEventHandler ( "onVehicleExplode", root, Exploded )
addEventHandler ( "onPlayerQuit", root, Exploded )
end
end
addCommandHandler("cow", cow)


function trash(player)
if isPedInVehicle (player) then 
local car = getPedOccupiedVehicle(player)
x,y,z = getElementPosition(player)
local trash = createObject(2890, x, y, z+10)
attachElements(trash, car)
addEventHandler ( "onVehicleExplode", root, Exploded )
addEventHandler ( "onPlayerQuit", root, Exploded )
end
end
addCommandHandler("trash", trash)


function ramp(player)
if isPedInVehicle (player) then 
local car = getPedOccupiedVehicle(player)
x,y,z = getElementPosition(player)
local ramp = createObject(1655, x, y, z+10)
attachElements(ramp, car,0,3.40,-1,0,0,180)
addEventHandler ( "onVehicleExplode", root, Exploded )
addEventHandler ( "onPlayerQuit", root, Exploded )
end
end
addCommandHandler("ramp", ramp)

function shark(player)
if isPedInVehicle (player) then 
local car = getPedOccupiedVehicle(player)
x,y,z = getElementPosition(player)
local shark = createObject(1608, x, y, z+10)
attachElements(shark, car)
addEventHandler ( "onVehicleExplode", root, Exploded )
addEventHandler ( "onPlayerQuit", root, Exploded )
end
end
addCommandHandler("shark", shark)


function Exploded ()
    local attachedElements = getAttachedElements ( source )
    for i,v in ipairs ( attachedElements ) do
        detachElements ( v, source )
		destroyElement(v)
    end
	removeEventHandler ( "onVehicleExplode", root, Exploded )
	removeEventHandler ( "onPlayerQuit", root, Exploded )
end

