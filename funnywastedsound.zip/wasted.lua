local sounds =  
{ 
    "die1.wav", 
    "die2.wav",
    "die3.wav",
	"die4.wav",
	"die5.wav",
	"die6.mp3",
}

local soundsw =  
{ 
    "die2.wav",
	"die4.wav",
	"die5.wav",
	"die7.mp3",
}

function wasted (killer, weapon, bodypart) 
	local sound = playSound(sounds [math.random( 1,#sounds )], false) 
	setSoundVolume(sound, 1.0) 
end
 
addEventHandler("onClientPlayerWasted", getLocalPlayer(), wasted) 

function kill (killer) 
local sound = playSound(soundsw [math.random( 1,#soundsw )], false)
    setSoundVolume(sound, 1.2) 
end 
addEventHandler("onClientPlayerWasted", killer, kill) 