local sx, sy = guiGetScreenSize ()
local tiempo = 150 -- milisegundos
local function moverCabeza()
	for _, player in pairs(getElementsByType("player")) do
		if isElement(player) then
			local x, y, z = getElementData(player, "cabeza:x"), getElementData(player, "cabeza:y"), getElementData(player, "cabeza:z")
			if x and y and z then
				setPedLookAt(player, x, y, z)
			end
		end
	end
end
addEventHandler("onClientRender", root, moverCabeza)

local function actualizarMov()
	local x, y, z = getWorldFromScreenPosition( sx/2, sy/2, 100 )
	triggerServerEvent("cabeza:mover", getLocalPlayer(), x, y, z)
end
setTimer(actualizarMov, tiempo, 0)