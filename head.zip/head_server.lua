
local function moverCabeza(x,y,z)
	if not isElement(source) or not x or not y or not z then
		return
	end
	setElementData(source, "cabeza:x", x)
	setElementData(source, "cabeza:y", y)
	setElementData(source, "cabeza:z", z)
end
addEvent("cabeza:mover", true)
addEventHandler("cabeza:mover", getRootElement(), moverCabeza)