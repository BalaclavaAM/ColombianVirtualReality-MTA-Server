function kickPing()
	for i, player in ipairs(getElementsByType("player")) do 
		if (getPlayerPing(player) >= 500) then 
			kickPlayer(player, "Tu ping es muy alto!")
		end
	end
end
setTimer(kickPing, 1000, 0)