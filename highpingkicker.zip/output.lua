
	outputChatBox ( "Ping Kicker mod has been activated", getRootElement(), 255, 255, 255, true )
	outputChatBox ( "#FFFFFFIf the Player ping was bigger than #00FFFF500 #FFFFFFthe player will get kicked.", getRootElement(), 255, 255, 255, true )
  outputChatBox ( "Mod created by : Baraa Ahmed ( Hiro )", getRootElement(), 255, 255, 255, true )
 outputChatBox("* " .. getPlayerName(source) .. " , Thank you for downloading my map")
