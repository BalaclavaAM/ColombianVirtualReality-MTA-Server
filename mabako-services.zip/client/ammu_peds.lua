function ammustaff_A()
ammu_a1 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_a1, 1, 294.94079589844, -40.216415405273, 1001.515625)
setPedVoice(ammu_a1, "PED_TYPE_DISABLED")
setElementFrozen (ammu_a1, true)
setElementDimension (ammu_a1, 1)

ammu_a2 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_a2, 1, 294.94079589844, -40.216415405273, 1001.515625)
setPedVoice(ammu_a2, "PED_TYPE_DISABLED")
setElementFrozen (ammu_a2, true )
setElementDimension (ammu_a2, 2)

ammu_a3 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_a3 , 1, 294.94079589844, -40.216415405273, 1001.515625)
setPedVoice(ammu_a3, "PED_TYPE_DISABLED")
setElementFrozen (ammu_a3 , true )
setElementDimension (ammu_a3 , 3)

ammu_a4 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_a4, 1, 294.94079589844, -40.216415405273, 1001.515625)
setPedVoice(ammu_a4, "PED_TYPE_DISABLED")
setElementFrozen (ammu_a4, true )
setElementDimension (ammu_a4, 4)

ammu_a5 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_a5, 1, 294.94079589844, -40.216415405273, 1001.515625)
setPedVoice(ammu_a5, "PED_TYPE_DISABLED")
setElementFrozen (ammu_a5, true )
setElementDimension (ammu_a5, 5)
end
addEventHandler('onClientResourceStart', getResourceRootElement(),ammustaff_A)

function ammustaff_B()
ammu_b1 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_b1, 4, 295.52349853516, -82.529228210449, 1001.515625)
setPedVoice(ammu_b1, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_b1, true )
setElementDimension (ammu_b1, 1)

ammu_b2 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_b2, 4, 295.52349853516, -82.529228210449, 1001.515625)
setPedVoice(ammu_b2, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_b2, true )
setElementDimension (ammu_b2, 2)

ammu_b3 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_b3, 4, 295.52349853516, -82.529228210449, 1001.515625)
setPedVoice(ammu_b3, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_b3, true )
setElementDimension (ammu_b3, 3)

ammu_b4 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_b4, 4, 295.52349853516, -82.529228210449, 1001.515625)
setPedVoice(ammu_b4, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_b4, true )
setElementDimension (ammu_b4, 4)

ammu_b5 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_b5, 4, 295.52349853516, -82.529228210449, 1001.515625)
setPedVoice(ammu_b5, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_b5, true )
setElementDimension (ammu_b5, 5)

end
addEventHandler('onClientResourceStart', getResourceRootElement(),ammustaff_B)


function ammustaff_C()
ammu_c1 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_c1, 6, 290.03698730469, -111.52514648438, 1001.515625)
setPedVoice(ammu_c1, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_c1, true )
setElementDimension (ammu_c1, 1)

ammu_c2 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_c2, 6, 290.03698730469, -111.52514648438, 1001.515625)
setPedVoice(ammu_c2, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_c2, true )
setElementDimension (ammu_c2, 2)

ammu_c3 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_c3, 6, 290.03698730469, -111.52514648438, 1001.515625)
setPedVoice(ammu_c3, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_c3, true )
setElementDimension (ammu_c3, 3)

ammu_c4 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_c4, 6, 290.03698730469, -111.52514648438, 1001.515625)
setPedVoice(ammu_c4, "PED_TYPE_DISABLED")
setElementFrozen (ammu_c4, true )
setElementDimension (ammu_c4, 4)

ammu_c5 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_c5, 6, 290.03698730469, -111.52514648438, 1001.515625)
setPedVoice(ammu_c5, "PED_TYPE_DISABLED")
setElementFrozen (ammu_c5, true )
setElementDimension (ammu_c5, 5)
end
addEventHandler('onClientResourceStart', getResourceRootElement(),ammustaff_C)


function ammustaff_D()
ammu_d1 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_d1, 6, 312.05715942383, -167.7857208252, 999.59375)
setPedVoice(ammu_d1, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_d1, true )
setElementDimension (ammu_d1, 1)

ammu_d2 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_d2, 6, 312.05715942383, -167.7857208252, 999.59375)
setPedVoice(ammu_d2, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_d2, true )
setElementDimension (ammu_d2, 2)

ammu_d3 = createPed ( 179, 0, 0, 0 )
setElementInterior (ammu_d3, 6, 312.05715942383, -167.7857208252, 999.59375)
setPedVoice(ammu_d3, "PED_TYPE_DISABLED")
setElementFrozen ( ammu_d3, true )
setElementDimension (ammu_d3, 3)
end
addEventHandler('onClientResourceStart', getResourceRootElement(),ammustaff_D)