	
	rpBlipOne = createBlip ( 1045.5 ,-2357.4 ,14, 33 ) -- sf blip
	--rpBlipTwo = createBlip ( x, y, z, 27 )
	