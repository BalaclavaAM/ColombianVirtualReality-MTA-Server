function robada ( hitPlayer, commandName, posX, posY, posZ )
fadeCamera(hitPlayer, false)
if isPedInVehicle (hitPlayer) then
	local vehicle = getPedOccupiedVehicle(hitPlayer)
		setVehicleFrozen(vehicle, true)
        setTimer(setVehicleFrozen, 1300, 1, vehicle, false)
		setTimer(fadeCamera, 1000, 1, hitPlayer, true)
        setTimer(setElementPosition, 1000, 1, vehicle,1015.2,-2356.1,16.7)
    else
        setElementPosition ( hitPlayer,1015.2,-2356.1,16.7)
setTimer(fadeCamera, 1000, 1, hitPlayer, true)
    end
end
addCommandHandler ( "robada", robada  )

function robadas ( hitPlayer, commandName, posX, posY, posZ )
fadeCamera(hitPlayer, false)
if isPedInVehicle (hitPlayer) then
	local vehicle = getPedOccupiedVehicle(hitPlayer)
		setVehicleFrozen(vehicle, true)
        setTimer(setVehicleFrozen, 1300, 1, vehicle, false)
		setTimer(fadeCamera, 1000, 1, hitPlayer, true)
        setTimer(setElementPosition, 1000, 1, vehicle,1015.2,-2356.1,2016.7)
    else
        setElementPosition ( hitPlayer,1015.2,-2356.1,2016.7)
setTimer(fadeCamera, 1000, 1, hitPlayer, true)
    end
end
addCommandHandler ( "robadas", robadas  )