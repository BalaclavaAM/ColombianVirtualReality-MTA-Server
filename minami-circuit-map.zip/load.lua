addEventHandler("onClientResourceStart", resourceRoot,
	function()
		txd = engineLoadTXD ("minami.txd")
		engineImportTXD (txd, 2283)

		dff = engineLoadDFF ("minami.dff")
		engineReplaceModel (dff, 2283)

		col = engineLoadCOL ("minami.col")
		engineReplaceCOL (col, 2283)

		engineSetModelLODDistance(2283, 2000)
end
)

addEventHandler("onClientResourceStop", resourceRoot,
	function()
		engineRestoreCOL(2283)
		engineRestoreModel(2283)
		destroyElement(dff)
		destroyElement(col)
		destroyElement(txd)
	end
)