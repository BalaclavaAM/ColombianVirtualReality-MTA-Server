local coords = {
	{ -764.00525, 697.95178, 18.44613},
	{ -801.27008, 515.67871, 17.99600},
}

local nonTPvehicles = {[425] = true, [520] = true, [476] = true, [447] = true, [464] = true, [432] = true}

function teleportMinami(source, command)

	local calc = math.random(#coords)
	local vehicle = getPedOccupiedVehicle(source)
	local vehModel = getElementModel(vehicle)

	if vehicle and nonTPvehicles[vehModel] then
		return outputChatBox("You cannot use /minami while in this specific vehicle!", source)
	end

	if vehicle then
		removePedFromVehicle(source)
		setElementPosition(source, unpack(coords[calc]))
	else
		setElementPosition(source, unpack(coords[calc]))
	end
end
addCommandHandler("minami", teleportMinami)