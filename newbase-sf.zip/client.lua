function onResourceStart()
local sound = playSound3D("http://provisioning.streamtheworld.com/pls/METRO_FMAAC.pls", -1795, 1222, 32, true) 
setSoundMaxDistance( sound, 40 )
setSoundVolume(sound, 0.01)
end
addEventHandler("onClientResourceStart", resourceRoot, onResourceStart)


local pedler = {
	{-1795.6, 1222, 32,"STR_Loop_A",260,69}, -- orta1 
	{-1795.6, 1224.4, 32,"STR_Loop_A",260,69}, -- orta1 
	{-1796, 1216, 32,"strip_F",260,33}, -- barmen 
	{-1795.72485, 1223.27527, 32.6562,"PUN_LOOP",260,217}, -- barmen 
				}
	
	for i,v in pairs(pedler) do
		local x,y,z,anim,rot,skin = unpack(v)
		local ped = createPed(skin,x,y,z)
		addEventHandler("onClientPedDamage", ped, function() ped:setHealth(100) cancelEvent() end)		
		setPedRotation (ped, rot )
		setPedAnimation(ped, "STRIP", anim, -1, true, true, false, false)

	end
	


	
	
	

		
