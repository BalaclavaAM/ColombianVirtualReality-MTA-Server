txd = engineLoadTXD ( "russian.txd" )
engineImportTXD ( txd, 13645 )
col = engineLoadCOL ( "russian.col" )
engineReplaceCOL ( col, 13645 )
dff = engineLoadDFF ( "russian.dff", 0 )
engineReplaceModel ( dff, 13645 )

