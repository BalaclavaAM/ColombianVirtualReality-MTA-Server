local active=0

function shout ( player, cmd, ... )
    if active>0 then return end
    local accountname = getAccountName ( getPlayerAccount ( player ) )
    if ((accountname=="MagicMora") or (accountname=="silennncer") or (accountname=="BalaclavaAM") or (accountname=="Virtual") or (accountname=="cazaputas42") or (accountname == "DokiC4C0RR0") or (accountname=="karamelo") or (accountname == "ReizerB") or (accountname == "DonBerni") or (accountname == "RicardoJorge") or (accountname == "Jimenez") or (accountname == "MataTombos23") or (accountname == "V-neko_Kawaii") and active==0) then
        local message = table.concat ( { ... }," " )
        textDisplay = textCreateDisplay ( )
        textItem = textCreateTextItem ( getPlayerName(player)..": "..message, 0.5, 0.5, 2, 205, 0, 0, 255, 3, "center", "center" )
        active=active+1
        textDisplayAddText ( textDisplay, textItem )
        for _, thePlayer in ipairs ( getElementsByType ( "player" ) ) do
            textDisplayAddObserver ( textDisplay, thePlayer )
        end
        setTimer (
            function ( )
                textDestroyTextItem ( textItem )
                textDestroyDisplay ( textDisplay )
                active=active-1
            end
            ,10000, 1
        )
    else
        outputChatBox ( "You cannot use this command!", player, 255, 12, 15 )
    end
end
addCommandHandler ( "anunciodj", shout )