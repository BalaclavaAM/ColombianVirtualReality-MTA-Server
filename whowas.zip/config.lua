-- ****************************************************************************
--
-- RECURSO: Whowas
-- ARCHIVO: config.lua
-- PROPOSITO: Configuraciones iniciales del script
-- CREADORES: Francisco Bermello < JUNIORCEDE >
--
-- ****************************************************************************

--Seleccione el tipo de conexion de base de datos puede ser mysql o sqlite
DBType = "mysql"

--Si elige el tipo de conexion sqlite estos datos los puede dejar vacíos caso contrario debe rellenarlos
DBhost = "127.0.0.1";
DBuser = "dhoyosg";
DBpassword = "20MTAmed03";
DBname = "zdhoyosg0";


--Intervalo de tiempo del cual se ejecutará la eliminación de datos
--Si no quiere que estos datos se eliminen asigne el valor 0 a la variable
timeDeleteInfo = 0

--[[
    Poner esta variable en true si es que quiere guardar la informacion de los usuarios conectados en el servidor en el momento que se inicia
    el script, caso contraio dejarlo en false
]]
refreshUserInGame = true

--[[
    Variable para controlar la diferencia horaria de su servidor
    Un ejemplo mi servidor tiene horario aleman, por lo que hay 6 horas de diferencia de la hora que deseo ver los logs
    en ese caso pondría un -6 ya que mi horario es menor al del servidor y debo restar 6 hrs
    --si fuera lo contrario solo dejar el numero en positivo, es decir si su hora es mayor a la del servidor
    --si no tiene diferencia horaria dejar en 0
]]
timeDifference = -6 --[-6]